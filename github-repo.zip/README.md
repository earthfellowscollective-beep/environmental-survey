# Earth Fellows Collective — Volunteer Perception Survey Dashboard

Interactive data dashboard presenting insights from 109 survey responses about eco-tourism volunteering perceptions in India.

## Live Dashboard
🔗 **[View Live Dashboard](https://<USERNAME>.github.io/<REPO-NAME>/)**

> Replace `<USERNAME>` and `<REPO-NAME>` with your actual GitHub username and repository name.

## Survey Highlights
- **109 respondents** (College students, Working professionals, Freelancers)
- **4.49/5** average interest in eco-volunteering
- **96%** want to be notified about opportunities
- **93%** open to paying for structured programs
- **#1 barrier**: 57% don't know where to find opportunities

## Tech Stack
- Pure HTML/CSS/JS — no build step needed
- Chart.js for interactive charts
- Google Fonts (DM Sans + Fraunces)
- GitHub Pages for hosting

## How to Update
1. Edit `index.html` directly on GitHub
2. Changes go live automatically via GitHub Pages

---
*Survey conducted Mar 24–30, 2026*
